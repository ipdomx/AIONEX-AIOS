from __future__ import annotations
import asyncio, hashlib, shutil, time, uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional


@dataclass
class BackupRecord:
    backup_id: str
    source: str
    destination: str
    checksum: str
    size_bytes: int
    created_at: float = field(default_factory=time.time)


class BackupManager:
    def __init__(self):
        self.records: Dict[str, BackupRecord] = {}
        self.lock = asyncio.Lock()

    @staticmethod
    def _checksum(path: Path) -> str:
        digest = hashlib.sha256()
        for file in sorted(p for p in path.rglob("*") if p.is_file()):
            digest.update(str(file.relative_to(path)).encode())
            with file.open("rb") as handle:
                for chunk in iter(lambda: handle.read(65536), b""):
                    digest.update(chunk)
        return digest.hexdigest()

    async def create_backup(self, source: str, destination_root: str) -> BackupRecord:
        src = Path(source)
        if not src.exists():
            raise FileNotFoundError(source)
        backup_id = uuid.uuid4().hex
        dst = Path(destination_root) / backup_id
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            dst.mkdir()
            shutil.copy2(src, dst / src.name)
        size = sum(p.stat().st_size for p in dst.rglob("*") if p.is_file())
        record = BackupRecord(backup_id, str(src), str(dst), self._checksum(dst), size)
        async with self.lock:
            self.records[backup_id] = record
        return record

    async def restore_backup(self, backup_id: str, destination: str) -> None:
        record = self.records[backup_id]
        src, dst = Path(record.destination), Path(destination)
        dst.mkdir(parents=True, exist_ok=True)
        for item in src.iterdir():
            target = dst / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)

    async def verify_backup(self, backup_id: str) -> bool:
        record = self.records[backup_id]
        return self._checksum(Path(record.destination)) == record.checksum

    async def list_backups(self) -> list[dict]:
        async with self.lock:
            return [vars(r).copy() for r in self.records.values()]


@dataclass
class BackupJob:
    job_id: str
    source: str
    destination: str
    interval_seconds: float
    next_run: float
    enabled: bool = True
    last_backup: Optional[str] = None


class BackupScheduler:
    def __init__(self, manager: BackupManager):
        self.manager, self.jobs, self.task = manager, {}, None
        self.shutdown_requested = False

    async def add_job(self, job_id: str, source: str, destination: str, interval_seconds: float) -> None:
        self.jobs[job_id] = BackupJob(job_id, source, destination, interval_seconds, time.time()+interval_seconds)

    async def run_once(self) -> None:
        now = time.time()
        for job in self.jobs.values():
            if job.enabled and now >= job.next_run:
                record = await self.manager.create_backup(job.source, job.destination)
                job.last_backup = record.backup_id
                job.next_run = time.time() + job.interval_seconds

    async def _worker(self):
        while not self.shutdown_requested:
            await self.run_once()
            await asyncio.sleep(1)

    async def start(self):
        if self.task is None:
            self.shutdown_requested = False
            self.task = asyncio.create_task(self._worker())

    async def stop(self):
        self.shutdown_requested = True
        if self.task:
            await self.task
            self.task = None
