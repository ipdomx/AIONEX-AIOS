from aios.kernel import AIOSKernel


def test_kernel_status():
    kernel = AIOSKernel()
    status = kernel.status()
    assert status['name'] == 'AIOS'
    assert status['version'] == '2.2.0-beta.3-phase.6'
    assert status['constitution'] == 'enforced'
